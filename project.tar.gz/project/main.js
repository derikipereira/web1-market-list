let produtos = [];

function addProduto() {
    const produtoInput = document.getElementById('produtoInput');
    const produtoQuantInput = document.getElementById('produtoQuant');
    const produtoText = produtoInput.value.trim();
    const productQuant = produtoQuantInput.value.trim();

    if (produtoText !== '') {
        const produto = {
            id: Date.now(),
            text: produtoText,
            quant: productQuant,
            completed: false
        };
        
        produtos.push(produto);
        renderprodutos();
        produtoInput.value = '';
        produtoQuantInput.value = '';
    }
}

function deleteproduto(produtoId) {
    produtos = produtos.filter(produto => produto.id !== produtoId);
    renderprodutos();
}

function toggleComplete(produtoId) {
    produtos = produtos.map(produto => {
        if (produto.id === produtoId) {
            return { ...produto, completed: !produto.completed };
        }
        return produto;
    });
    renderprodutos();
}

function renderprodutos() {
    const produtoList = document.getElementById('produtoList');
    produtoList.innerHTML = '';
    
    produtos.forEach(produto => {
        const li = document.createElement('li');
        li.className = `produto-item ${produto.completed ? 'completed' : ''}`;
        
        li.innerHTML = `
            <span style="text-decoration:${produto.completed ? 'line-through' : ''};"}>${produto.text} - ${produto.quant}</span>
            <div class="produto-actions">
                <button onclick="toggleComplete(${produto.id})" class="complete-btn">
                    ${produto.completed ? 'Desfazer' : 'Completar'}
                </button>
                <button onclick="deleteproduto(${produto.id})" class="delete-btn">Deletar</button>
            </div>
        `;
        
        produtoList.appendChild(li);
    });
}

document.getElementById('produtoInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        addproduto();
    }
});

renderprodutos();